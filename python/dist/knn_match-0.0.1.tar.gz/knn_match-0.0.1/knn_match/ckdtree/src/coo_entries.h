#ifndef CKDTREE_COO_ENTRIES
#define CKDTREE_COO_ENTRIES

struct coo_entry {
    ckdtree_intp_t i;
    ckdtree_intp_t j;
    double v;
};

#endif

